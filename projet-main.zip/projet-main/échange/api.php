<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// ============================================================
// SIMULATION DE BASE DE DONNÉES (en production : utilisez MySQL/PDO)
// ============================================================
// En vrai projet, remplacez par une vraie DB :
// $pdo = new PDO("mysql:host=localhost;dbname=exchange", "user", "pass");
// ============================================================

session_start();

// Données simulées (en mémoire / fichier JSON)
$dataFile = __DIR__ . '/data.json';

function loadData($dataFile) {
    if (!file_exists($dataFile)) {
        $initial = [
            'users' => [
                ['id' => 1, 'username' => 'Alice', 'avatar' => '🧝'],
                ['id' => 2, 'username' => 'Bob',   'avatar' => '🧙'],
            ],
            'items' => [
                ['id' => 1, 'owner_id' => 1, 'name' => 'Épée en acier',    'icon' => '⚔️',  'rarity' => 'rare'],
                ['id' => 2, 'owner_id' => 1, 'name' => 'Bouclier doré',    'icon' => '🛡️',  'rarity' => 'épique'],
                ['id' => 3, 'owner_id' => 1, 'name' => 'Potion de vie',    'icon' => '🧪',  'rarity' => 'commun'],
                ['id' => 4, 'owner_id' => 2, 'name' => 'Arc enchanté',     'icon' => '🏹',  'rarity' => 'rare'],
                ['id' => 5, 'owner_id' => 2, 'name' => 'Grimoire ancien',  'icon' => '📖',  'rarity' => 'légendaire'],
                ['id' => 6, 'owner_id' => 2, 'name' => 'Bague magique',    'icon' => '💍',  'rarity' => 'épique'],
            ],
            'trades' => [],
            'next_item_id' => 7,
            'next_trade_id' => 1,
        ];
        file_put_contents($dataFile, json_encode($initial, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        return $initial;
    }
    return json_decode(file_get_contents($dataFile), true);
}

function saveData($dataFile, $data) {
    file_put_contents($dataFile, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

function respond($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit();
}

$data   = loadData($dataFile);
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$body   = json_decode(file_get_contents('php://input'), true) ?? [];

// ============================================================
// ROUTES
// ============================================================

// GET /api.php?action=state  — état complet
if ($method === 'GET' && $action === 'state') {
    respond([
        'users' => $data['users'],
        'items' => $data['items'],
        'trades' => $data['trades'],
    ]);
}

// POST /api.php?action=add_item  — ajouter un objet
if ($method === 'POST' && $action === 'add_item') {
    $owner_id = (int)($body['owner_id'] ?? 0);
    $name     = trim($body['name'] ?? '');
    $icon     = trim($body['icon'] ?? '📦');
    $rarity   = trim($body['rarity'] ?? 'commun');

    if (!$owner_id || !$name) respond(['error' => 'Données manquantes'], 400);

    $newItem = [
        'id'       => $data['next_item_id']++,
        'owner_id' => $owner_id,
        'name'     => $name,
        'icon'     => $icon,
        'rarity'   => $rarity,
    ];
    $data['items'][] = $newItem;
    saveData($dataFile, $data);
    respond(['success' => true, 'item' => $newItem]);
}

// POST /api.php?action=propose_trade  — proposer un échange
if ($method === 'POST' && $action === 'propose_trade') {
    $from_user   = (int)($body['from_user']   ?? 0);
    $to_user     = (int)($body['to_user']     ?? 0);
    $offer_ids   = $body['offer_ids']   ?? [];
    $request_ids = $body['request_ids'] ?? [];

    if (!$from_user || !$to_user || empty($offer_ids) || empty($request_ids)) {
        respond(['error' => 'Sélectionnez au moins un objet de chaque côté'], 400);
    }

    // Vérifier ownership
    foreach ($offer_ids as $id) {
        $item = array_values(array_filter($data['items'], fn($i) => $i['id'] == $id))[0] ?? null;
        if (!$item || $item['owner_id'] != $from_user)
            respond(['error' => "L'objet #$id n'appartient pas à l'utilisateur $from_user"], 400);
    }
    foreach ($request_ids as $id) {
        $item = array_values(array_filter($data['items'], fn($i) => $i['id'] == $id))[0] ?? null;
        if (!$item || $item['owner_id'] != $to_user)
            respond(['error' => "L'objet #$id n'appartient pas à l'utilisateur $to_user"], 400);
    }

    $trade = [
        'id'          => $data['next_trade_id']++,
        'from_user'   => $from_user,
        'to_user'     => $to_user,
        'offer_ids'   => $offer_ids,
        'request_ids' => $request_ids,
        'status'      => 'en_attente',
        'created_at'  => date('Y-m-d H:i:s'),
    ];
    $data['trades'][] = $trade;
    saveData($dataFile, $data);
    respond(['success' => true, 'trade' => $trade]);
}

// POST /api.php?action=respond_trade  — accepter / refuser
if ($method === 'POST' && $action === 'respond_trade') {
    $trade_id = (int)($body['trade_id'] ?? 0);
    $response = $body['response'] ?? ''; // 'accept' | 'reject'
    $user_id  = (int)($body['user_id']  ?? 0);

    $tradeIndex = null;
    foreach ($data['trades'] as $k => $t) {
        if ($t['id'] == $trade_id) { $tradeIndex = $k; break; }
    }
    if ($tradeIndex === null) respond(['error' => 'Échange introuvable'], 404);

    $trade = $data['trades'][$tradeIndex];
    if ($trade['to_user'] != $user_id) respond(['error' => 'Non autorisé'], 403);
    if ($trade['status'] !== 'en_attente') respond(['error' => 'Échange déjà traité'], 400);

    if ($response === 'accept') {
        // Transférer les objets
        foreach ($data['items'] as &$item) {
            if (in_array($item['id'], $trade['offer_ids']))   $item['owner_id'] = $trade['to_user'];
            if (in_array($item['id'], $trade['request_ids'])) $item['owner_id'] = $trade['from_user'];
        }
        unset($item);
        $data['trades'][$tradeIndex]['status'] = 'accepté';
    } else {
        $data['trades'][$tradeIndex]['status'] = 'refusé';
    }

    saveData($dataFile, $data);
    respond(['success' => true, 'trade' => $data['trades'][$tradeIndex]]);
}

// POST /api.php?action=reset  — réinitialiser les données
if ($method === 'POST' && $action === 'reset') {
    if (file_exists($dataFile)) unlink($dataFile);
    $data = loadData($dataFile);
    respond(['success' => true]);
}

respond(['error' => 'Action inconnue'], 404);